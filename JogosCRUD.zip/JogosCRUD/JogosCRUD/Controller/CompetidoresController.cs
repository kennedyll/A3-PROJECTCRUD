using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompeticaoEscolar.Data;
using CompeticaoEscolar.Models;

namespace CompeticaoEscolar.Controllers
{
    [Route("api/[controller]")]
    public class CompetidoresController : ControllerBase
    {
        private readonly CompeticaoBD _context;

        public CompetidoresController(CompeticaoBD context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Competidor>>> GetCompetidores()
        {
            return await _context.Competidores.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Competidor>> GetCompetidor(int id)
        {
            var competidor = await _context.Competidores.FindAsync(id);

            if (competidor == null)
            {
                return NotFound();
            }

            return competidor;
        }

        [HttpPost]
        public async Task<ActionResult<Competidor>> PostCompetidor(Competidor competidor)
        {
            _context.Competidores.Add(competidor);
            await _context.SaveChangesAsync();

            AtualizarColocacoes(competidor.CompeticaoId);

            return CreatedAtAction(nameof(GetCompetidor), new { id = competidor.Id }, competidor);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutCompetidor(int id, Competidor competidor)
        {
            if (id != competidor.Id)
            {
                return BadRequest();
            }

            _context.Entry(competidor).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();

                AtualizarColocacoes(competidor.CompeticaoId);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CompetidorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCompetidor(int id)
        {
            var competidor = await _context.Competidores.FindAsync(id);
            if (competidor == null)
            {
                return NotFound();
            }

            int competicaoId = competidor.CompeticaoId;

            _context.Competidores.Remove(competidor);
            await _context.SaveChangesAsync();

            AtualizarColocacoes(competicaoId);

            return NoContent();
        }

        private bool CompetidorExists(int id)
        {
            return _context.Competidores.Any(e => e.Id == id);
        }

        private void AtualizarColocacoes(int competicaoId)
        {
            var competicao = _context.Competicoes.Include(c => c.Competidores).FirstOrDefault(c => c.Id == competicaoId);
            if (competicao != null)
            {
                var competidores = competicao.Competidores.OrderByDescending(c => c.Pontuacao).ToList();
                for (int i = 0; i < competidores.Count; i++)
                {
                    competidores[i].Colocacao = i + 1;
                }
                _context.SaveChanges();
            }
        }
    }
}
