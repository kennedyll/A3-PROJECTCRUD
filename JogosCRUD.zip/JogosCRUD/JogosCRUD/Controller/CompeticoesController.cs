using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CompeticaoEscolar.Data;
using CompeticaoEscolar.Models;

namespace CompeticaoEscolar.Controllers
{
    [Route("api/[controller]")]
    public class CompeticoesController : ControllerBase
    {
        private readonly CompeticaoBD _context;

        public CompeticoesController(CompeticaoBD context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Competicao>>> GetCompeticoes()
        {
            return await _context.Competicoes.Include(c => c.Competidores).ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Competicao>> GetCompeticao(int id)
        {
            var competicao = await _context.Competicoes.Include(c => c.Competidores).FirstOrDefaultAsync(c => c.Id == id);

            if (competicao == null)
            {
                return NotFound();
            }

            return competicao;
        }

        [HttpPost]
        public async Task<ActionResult<Competicao>> PostCompeticao(Competicao competicao)
        {
            _context.Competicoes.Add(competicao);
            await _context.SaveChangesAsync();

            AtualizarColocacoes(competicao.Id);

            return CreatedAtAction(nameof(GetCompeticao), new { id = competicao.Id }, competicao);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutCompeticao(int id, Competicao competicao)
        {
            if (id != competicao.Id)
            {
                return BadRequest();
            }

            _context.Entry(competicao).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();

                AtualizarColocacoes(id);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CompeticaoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCompeticao(int id)
        {
            var competicao = await _context.Competicoes.Include(c => c.Competidores).FirstOrDefaultAsync(c => c.Id == id);
            if (competicao == null)
            {
                return NotFound();
            }

            _context.Competicoes.Remove(competicao);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CompeticaoExists(int id)
        {
            return _context.Competicoes.Any(e => e.Id == id);
        }

        private void AtualizarColocacoes(int competicaoId)
        {
            var competicao = _context.Competicoes.Include(c => c.Competidores).FirstOrDefault(c => c.Id == competicaoId);

            if (competicao != null)
            {
                var competidores = competicao.Competidores.OrderByDescending(c => c.Pontuacao).ToList();
                for (int i = 0; i < competidores.Count; i++)
                {
                    competidores[i].Colocacao = i + 1;
                }
                _context.SaveChanges();
            }
        }
    }
}
