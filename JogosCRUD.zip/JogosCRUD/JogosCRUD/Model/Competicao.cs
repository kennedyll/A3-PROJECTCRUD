namespace CompeticaoEscolar.Models

{
    public class Competicao
    {
        public int Id { get; set; }
        public string Esporte {get; set;} = string.Empty;
        public string NomeEquip { get; set; } = string.Empty;
        public DateTime Data { get; set; }
        public List<Competidor> Competidores { get; set; } = new List<Competidor>();
    }
}

