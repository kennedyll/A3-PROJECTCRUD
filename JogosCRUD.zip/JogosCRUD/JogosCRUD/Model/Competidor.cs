namespace CompeticaoEscolar.Models
{
    public class Competidor
    {
        public int Id { get; set; }
        public string Competidores { get; set; } = string.Empty;
        public int Pontuacao { get; set; }
        public int Colocacao { get; set; }
        public int CompeticaoId { get; set; }
    }
}
