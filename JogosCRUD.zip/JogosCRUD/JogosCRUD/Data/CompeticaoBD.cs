using Microsoft.EntityFrameworkCore;
using CompeticaoEscolar.Models;

namespace CompeticaoEscolar.Data
{
    public class CompeticaoBD : DbContext
    {
        public CompeticaoBD(DbContextOptions<CompeticaoBD> options) : base(options)
        {
        }

        public DbSet<Competicao> Competicoes { get; set; }
        public DbSet<Competidor> Competidores { get; set; }
    }
}